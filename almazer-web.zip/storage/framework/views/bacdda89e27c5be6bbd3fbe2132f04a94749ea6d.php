<?php if(Auth::user()->type==='staff'): ?>
<li class="<?php echo e(Request::is('users*') ? 'active' : ''); ?>">
    <a href="<?php echo route('users.index'); ?>"><i class="fa fa-edit"></i><span>Users</span></a>
</li>
<li class="<?php echo e(Request::is('users*') ? 'active' : ''); ?>">
    <a href="<?php echo route('article.index'); ?>"><i class="fa fa-newspaper-o"></i><span>Articles</span></a>
</li>
<li class="<?php echo e(Request::is('users*') ? 'active' : ''); ?>">
    <a href="<?php echo route('album.index'); ?>"><i class="fa fa-book"></i><span>Album</span></a>
</li>
<?php endif; ?>


<?php /**PATH C:\laragon\www\almazer-web\resources\views/layouts/menu.blade.php ENDPATH**/ ?>