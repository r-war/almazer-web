<!-- Type Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('type', 'Type:'); ?>

    <?php echo Form::text('type', null, ['class' => 'form-control']); ?>

</div>

<!-- Number Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('number', 'Number:'); ?>

    <?php echo Form::text('number', null, ['class' => 'form-control']); ?>

</div>

<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<!-- Email Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('email', 'Email:'); ?>

    <?php echo Form::email('email', null, ['class' => 'form-control']); ?>

</div>

<!-- Vin Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('vin', 'Vin:'); ?>

    <?php echo Form::text('vin', null, ['class' => 'form-control']); ?>

</div>

<!-- Date Of Birth Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('date_of_birth', 'Date Of Birth:'); ?>

    <input class="form-control" type="date" name="date_of_birth" value="<?php echo e($user['date_of_birth']->format('Y-m-d')); ?>">
</div>

<!-- Address Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('address', 'Address:'); ?>

    <?php echo Form::textarea('address', null, ['class' => 'form-control']); ?>

</div>

<!-- Mobile Phone Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('mobile_phone', 'Mobile Phone:'); ?>

    <?php echo Form::text('mobile_phone', null, ['class' => 'form-control']); ?>

</div>

<!-- License Plate Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('license_plate', 'License Plate:'); ?>

    <?php echo Form::text('license_plate', null, ['class' => 'form-control']); ?>

</div>

<!-- Size Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('size', 'Size:'); ?>

    <?php echo Form::text('size', null, ['class' => 'form-control']); ?>

</div>

<!-- Email Verified At Field -->
<!-- <div class="form-group col-sm-6">
    <?php echo Form::label('email_verified_at', 'Email Verified At:'); ?>

    <?php echo Form::date('email_verified_at', null, ['class' => 'form-control','id'=>'email_verified_at']); ?>

</div> -->

<!-- Password Field -->
<!-- <div class="form-group col-sm-6">
    <?php echo Form::label('password', 'Password:'); ?>

    <?php echo Form::password('password', ['class' => 'form-control']); ?>

</div>

<div class="form-group col-sm-6">
    <?php echo Form::label('remember_token', 'Remember Token:'); ?>

    <?php echo Form::text('remember_token', null, ['class' => 'form-control']); ?>

</div> -->

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('users.index'); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH C:\laragon\www\almazer-web\resources\views/users/fields.blade.php ENDPATH**/ ?>