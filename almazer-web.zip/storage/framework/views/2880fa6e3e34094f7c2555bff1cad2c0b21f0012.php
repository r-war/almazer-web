<div class="table-responsive">
    <table class="table" id="users-table">
        <thead>
            <tr>
                <th>Type</th>
        <th>Number</th>
        <th>Name</th>
        <th>Email</th>
        <th>Vin</th>
        <th>Date Of Birth</th>
        <th>Address</th>
        <th>Mobile Phone</th>
        <th>License Plate</th>
        <th>Size</th>
        <th>Email Verified At</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo $user->type; ?></td>
            <td><?php echo $user->number; ?></td>
            <td><?php echo $user->name; ?></td>
            <td><?php echo $user->email; ?></td>
            <td><?php echo $user->vin; ?></td>
            <td><?php echo $user->date_of_birth; ?></td>
            <td><?php echo $user->address; ?></td>
            <td><?php echo $user->mobile_phone; ?></td>
            <td><?php echo $user->license_plate; ?></td>
            <td><?php echo $user->size; ?></td>
            <td><?php echo $user->email_verified_at; ?></td>
                <td>
                    <?php echo Form::open(['route' => ['users.destroy', $user->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo route('users.show', [$user->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="<?php echo route('users.edit', [$user->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\laragon\www\almazer-web\resources\views/users/table.blade.php ENDPATH**/ ?>