<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $user->id; ?></p>
</div>

<!-- Type Field -->
<div class="form-group">
    <?php echo Form::label('type', 'Type:'); ?>

    <p><?php echo $user->type; ?></p>
</div>

<!-- Number Field -->
<div class="form-group">
    <?php echo Form::label('number', 'Number:'); ?>

    <p><?php echo $user->number; ?></p>
</div>

<!-- Name Field -->
<div class="form-group">
    <?php echo Form::label('name', 'Name:'); ?>

    <p><?php echo $user->name; ?></p>
</div>

<!-- Email Field -->
<div class="form-group">
    <?php echo Form::label('email', 'Email:'); ?>

    <p><?php echo $user->email; ?></p>
</div>

<!-- Vin Field -->
<div class="form-group">
    <?php echo Form::label('vin', 'Vin:'); ?>

    <p><?php echo $user->vin; ?></p>
</div>

<!-- Date Of Birth Field -->
<div class="form-group">
    <?php echo Form::label('date_of_birth', 'Date Of Birth:'); ?>

    <p><?php echo $user->date_of_birth; ?></p>
</div>

<!-- Address Field -->
<div class="form-group">
    <?php echo Form::label('address', 'Address:'); ?>

    <p><?php echo $user->address; ?></p>
</div>

<!-- Mobile Phone Field -->
<div class="form-group">
    <?php echo Form::label('mobile_phone', 'Mobile Phone:'); ?>

    <p><?php echo $user->mobile_phone; ?></p>
</div>

<!-- License Plate Field -->
<div class="form-group">
    <?php echo Form::label('licens_plate', 'License Plate:'); ?>

    <p><?php echo $user->licens_plate; ?></p>
</div>

<!-- Size Field -->
<div class="form-group">
    <?php echo Form::label('size', 'Size:'); ?>

    <p><?php echo $user->size; ?></p>
</div>

<!-- Email Verified At Field -->
<div class="form-group">
    <?php echo Form::label('email_verified_at', 'Email Verified At:'); ?>

    <p><?php echo $user->email_verified_at; ?></p>
</div>

<!-- Password Field -->
<div class="form-group">
    <?php echo Form::label('password', 'Password:'); ?>

    <p><?php echo $user->password; ?></p>
</div>

<!-- Remember Token Field -->
<div class="form-group">
    <?php echo Form::label('remember_token', 'Remember Token:'); ?>

    <p><?php echo $user->remember_token; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $user->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $user->updated_at; ?></p>
</div>

<?php /**PATH C:\laragon\www\almazer-web\resources\views/users/show_fields.blade.php ENDPATH**/ ?>