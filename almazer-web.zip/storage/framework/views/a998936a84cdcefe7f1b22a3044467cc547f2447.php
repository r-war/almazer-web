<div class="table-responsive">
    <table class="table" id="users-table">
        <thead>
            <tr>
                <th>Date</th>
                <th>Name</th>
                <th>cover</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo $article->date; ?></td>
            <td><?php echo $article->name; ?></td>
            <td><?php echo $article->picture; ?></td>
                <td>
                    <?php echo Form::open(['route' => ['article.destroy', $article->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo route('article.edit', [$article->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\laragon\www\almazer-web\resources\views/backend/article/table.blade.php ENDPATH**/ ?>