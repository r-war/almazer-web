<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            Album Picture
        </h1>
   </section>
   <div class="content">
       <?php echo $__env->make('adminlte-templates::common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       <div class="box box-primary">
           <div class="box-body">
               <div class="row">
                <?php
                $form = [
                    'route' => ['album-picture.update', $model->id, 'album_id'=>$id],
                    'files' => true
                ];
                ?>
                   <?php echo Form::model($model, $form); ?>

                        <?php echo e(method_field('PUT')); ?>

                        <?php echo $__env->make('backend.album-picture.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                   <?php echo Form::close(); ?>

               </div>
           </div>
       </div>
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\almazer-web\resources\views/backend/album-picture/edit.blade.php ENDPATH**/ ?>