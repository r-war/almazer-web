<div class="table-responsive">
    <table class="table" id="users-table">
        <thead>
            <tr>
                <th>Index</th>
                <th>Name</th>
                <th>Picture</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $oPicture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo $picture->index; ?></td>
            <td><?php echo $picture->name; ?></td>
            <td><?php echo $picture->picture; ?></td>
                <td>
                    <?php echo Form::open(['route' => ['album-picture.destroy', $picture->id, 'album_id'=>$id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        
                        <a href="<?php echo route('album-picture.edit', [$picture->id, 'album_id'=>$id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\laragon\www\almazer-web\resources\views/backend/album-picture/table.blade.php ENDPATH**/ ?>