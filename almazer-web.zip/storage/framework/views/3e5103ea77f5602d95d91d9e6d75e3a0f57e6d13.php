<!-- Index Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('index', 'index:'); ?>

    <?php echo Form::text('index', null, ['class' => 'form-control']); ?>

</div>

<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<!-- Cover Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('picture', 'Picture:'); ?>

    <?php echo Form::file('picture', ['class' => 'form-control']); ?>

</div>


<!-- Cover Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('description', 'Description:'); ?>

    <?php echo Form::textarea('description', null, ['class' => 'form-control', 'id'=>'editor1']); ?>

</div>



<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('album-picture.index', ['album_id'=>$id]); ?>" class="btn btn-default">Cancel</a>
</div>

<script src="//cdn.ckeditor.com/4.13.1/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace( 'description', {
        filebrowserUploadUrl: "<?php echo e(route('upload', ['_token' => csrf_token() ])); ?>",
        filebrowserUploadMethod: 'form'
    } );
</script><?php /**PATH C:\laragon\www\almazer-web\resources\views/backend/album-picture/fields.blade.php ENDPATH**/ ?>